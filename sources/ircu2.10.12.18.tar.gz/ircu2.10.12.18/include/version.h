/*
 * version.h
 *
 * $Id$
 */
#ifndef INCLUDED_version_h
#define INCLUDED_version_h

extern const char *version;
extern const char *creation;
extern const char *infotext[];
extern const char *generation;

#endif /* INCLUDED_version_h */
